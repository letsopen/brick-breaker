const canvas = wx.createCanvas()
const ctx = canvas.getContext('2d')

// 游戏配置
const config = {
  canvasWidth: canvas.width,
  canvasHeight: canvas.height,
  paddleHeight: 20,
  paddleWidth: 100,
  ballRadius: 10,
  brickRowCount: 5,  // 保持5列不变
  brickColumnCount: 3,
  brickPadding: 10,
  brickOffsetTop: 30,
  brickOffsetLeft: 30,
  ballSpeed: 4
}

// 计算砖块宽度，使其自适应屏幕
config.brickWidth = (config.canvasWidth - 2 * config.brickOffsetLeft - (config.brickRowCount - 1) * config.brickPadding) / config.brickRowCount;
config.brickHeight = 20;

// 初始化挡板
const paddle = {
  x: config.canvasWidth / 2 - config.paddleWidth / 2,
  y: config.canvasHeight - config.paddleHeight - 10,
  width: config.paddleWidth,
  height: config.paddleHeight
}

// 初始化小球
const ball = {
  x: config.canvasWidth / 2,
  y: config.canvasHeight - 30,
  dx: config.ballSpeed,
  dy: -config.ballSpeed,
  radius: config.ballRadius
}

// 初始化砖块
const bricks = []
for (let c = 0; c < config.brickColumnCount; c++) {
  bricks[c] = []
  for (let r = 0; r < config.brickRowCount; r++) {
    bricks[c][r] = { x: 0, y: 0, status: 1 }
  }
}

// 触摸事件处理
wx.onTouchMove((res) => {
  const touch = res.touches[0]
  const newX = touch.clientX - config.paddleWidth / 2
  
  // 确保挡板不会移出画布
  if (newX >= 0 && newX + config.paddleWidth <= config.canvasWidth) {
    paddle.x = newX
  }
})

// 碰撞检测
function collisionDetection() {
  for (let c = 0; c < config.brickColumnCount; c++) {
    for (let r = 0; r < config.brickRowCount; r++) {
      const b = bricks[c][r]
      if (b.status === 1) {
        // 计算球与砖块的距离
        const ballCenterX = ball.x;
        const ballCenterY = ball.y;
        const brickCenterX = b.x + config.brickWidth / 2;
        const brickCenterY = b.y + config.brickHeight / 2;
        
        // 计算球心到砖块最近的点的距离
        const distX = Math.abs(ballCenterX - brickCenterX);
        const distY = Math.abs(ballCenterY - brickCenterY);
        
        if (distX <= (config.brickWidth / 2 + ball.radius) && 
            distY <= (config.brickHeight / 2 + ball.radius)) {
          // 确定碰撞方向
          if (distX <= config.brickWidth / 2) {
            // 垂直碰撞
            ball.dy = -ball.dy;
          } else if (distY <= config.brickHeight / 2) {
            // 水平碰撞
            ball.dx = -ball.dx;
          } else {
            // 角落碰撞
            ball.dx = -ball.dx;
            ball.dy = -ball.dy;
          }
          b.status = 0;
        }
      }
    }
  }
}

// 绘制球
function drawBall() {
  ctx.beginPath()
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2)
  ctx.fillStyle = '#0095DD'
  ctx.fill()
  ctx.closePath()
}

// 绘制挡板
function drawPaddle() {
  ctx.beginPath()
  ctx.rect(paddle.x, paddle.y, paddle.width, paddle.height)
  ctx.fillStyle = '#0095DD'
  ctx.fill()
  ctx.closePath()
}

// 绘制砖块
function drawBricks() {
  for (let c = 0; c < config.brickColumnCount; c++) {
    for (let r = 0; r < config.brickRowCount; r++) {
      if (bricks[c][r].status === 1) {
        // 使用计算后的砖块宽度进行绘制
        const brickX = r * (config.brickWidth + config.brickPadding) + config.brickOffsetLeft;
        const brickY = c * (config.brickHeight + config.brickPadding) + config.brickOffsetTop;
        bricks[c][r].x = brickX;
        bricks[c][r].y = brickY;
        ctx.beginPath();
        ctx.rect(brickX, brickY, config.brickWidth, config.brickHeight);
        ctx.fillStyle = '#0095DD';
        ctx.fill();
        ctx.closePath();
      }
    }
  }
}

// 游戏主循环
function draw() {
  ctx.clearRect(0, 0, config.canvasWidth, config.canvasHeight)
  
  drawBricks()
  drawBall()
  drawPaddle()
  collisionDetection()
  
  // 优化墙壁碰撞检测
  const nextX = ball.x + ball.dx;
  const nextY = ball.y + ball.dy;
  
  // 左右墙壁碰撞
  if (nextX + ball.radius > config.canvasWidth || nextX - ball.radius < 0) {
    ball.dx = -ball.dx;
  }
  
  // 上墙碰撞
  if (nextY - ball.radius < 0) {
    ball.dy = -ball.dy;
  } else if (nextY + ball.radius > paddle.y) { // 修改这里，使用挡板的y坐标作为判断点
    // 优化挡板碰撞检测
    const paddleLeft = paddle.x;
    const paddleRight = paddle.x + paddle.width;
    
    if (ball.x >= paddleLeft - ball.radius && 
        ball.x <= paddleRight + ball.radius && 
        nextY + ball.radius >= paddle.y && 
        ball.y < paddle.y) { // 添加这个条件确保球在挡板上方
      
      // 根据击中挡板的位置改变反弹角度
      const hitPos = (ball.x - paddleLeft) / paddle.width;
      const angle = -75 + (150 * hitPos); // -75度到75度
      const speed = Math.sqrt(ball.dx * ball.dx + ball.dy * ball.dy);
      const angleRad = angle * Math.PI / 180;
      
      ball.dx = speed * Math.sin(angleRad);
      ball.dy = -speed * Math.cos(angleRad);
      
      // 确保球不会卡在挡板里
      ball.y = paddle.y - ball.radius;
    } else if (nextY + ball.radius > config.canvasHeight) {
      // 游戏结束逻辑
      wx.showModal({
        title: '游戏结束',
        content: '点击确定重新开始',
        success: (res) => {
          if (res.confirm) {
            // 重置球的位置
            ball.x = config.canvasWidth / 2
            ball.y = config.canvasHeight - 30
            ball.dx = config.ballSpeed
            ball.dy = -config.ballSpeed
            // 重置砖块
            for (let c = 0; c < config.brickColumnCount; c++) {
              for (let r = 0; r < config.brickRowCount; r++) {
                bricks[c][r].status = 1
              }
            }
          }
        }
      })
      return;
    }
  }
  
  ball.x += ball.dx;
  ball.y += ball.dy;
  
  requestAnimationFrame(draw);
}

draw()